import java.util.*;
import java.io.*;

public class Product {

	
	public String productName;
	public String productID;
	public double productPrice;
	public int quantity;
	 
	
	//Constructors
		public Product() {
			this.productID = "productID";
			this.productName = "productName";
			this.quantity = 1;
			this.productPrice = 1;
			
		}
	
		public Product(String productID, String productName, int quantity, double price) {
			try {
				this.setProductName(productName);
				this.setProductID(productID);
				this.setPrice(price);
				this.setQuantity(quantity);
			}catch(Exception e) {
				this.productName = "productName";
				this.productID = "productID";
				this.productPrice = 1.00;
				this.quantity =1;
				
			}
		}
		//productName getter and setter functions
		public String getProductName() {
			return this.productName;
		}
		public void setProductName(String productName) throws Exception{
		if(productName ==null || productName == "") {
			throw new Exception("productName cannot be null or empty string");
		}
		this.productName = productName;
		}
		
		//productID getter and setter functions
		public String getProductID() {
			return this.productID;
		}
		public void setProductID(String productID) throws Exception{
			if(productID == null || productID == "") {
				throw new Exception("productID cannot be null or empty string");
			}
			this.productID = productID;
			}
		
		//price getter and setter
		public double getPrice() {
			return this.productPrice;
		}
		public void setPrice(double price) throws Exception {
			if(price < 0.00) {
				throw new Exception("Price cannot be less than zero");
			}
			this.productPrice = price;
		} 
		
		//quantity getter and setter
		public int getQuantity() {
			return this.quantity;
		}
		public void setQuantity(int quantity) throws Exception {
			if(quantity < 0) {
				throw new Exception("Quantity cannot be less than zero");
			}
			this.quantity = quantity;
		} 
		static double totalAmount (int quantity, double price) {
			double total = quantity*price;
			return total; 
		}
		
		//toString functons to display Shopping_Cart Object to String
		public String toString() {
			String return_string = "";
			
			return_string +="Product Name: " + this.productName + "\n";
			return_string +="Product ID: " + this.productID + "\n";
			return_string +="Price: $ " + this.productPrice + "\n";
			return_string +="Quantity: " + this.quantity + "\n";
			
			return return_string;
			
		} 
		/**
		 * 
		 * @param shopping_list - List of Shopping_Cart Ojects to print to standard out
		 */ 
		
		public static void printShoppingList(List<Product>shopping_list) {
			for(int i =0; i<shopping_list.size(); i++) {
				System.out.println(shopping_list.get(i).toString());
			}
		}
		/**
		 * 
		 * @param filepath - File path to csv file that contains Shopping_Cart data to read
		 * @return - Shopping_Cart ArrayList containing csv product data
		 */
		
		public static  ArrayList<Product>importFile(String filepath){
			ArrayList<Product>shopping_list = new ArrayList<Product>();
			
			File file = new File(filepath);

			try {
				Scanner scanner = new Scanner(file);
			while(scanner.hasNextLine()) {
				
				String data = scanner.nextLine();
				String [] row = data.split(",");
				
				String productName = "";
				String productID = "";
				double price = 0;
				int quantity = 0;
				
			
				try {
					productID= row[0];
					productName = row[1];
					quantity = Integer.parseInt(row[2]);
					price = Double.parseDouble(row[3]);
					
					
				}
				catch(ArrayIndexOutOfBoundsException e) {
					System.out.println("Could not import row, less than 3 values given for row");
					continue;
					
				} 
				catch(NumberFormatException e) {
					System.out.println("Could not import row, failed to parse price column");
				} 
				catch(Exception e) {
					System.out.println("Could not import row");
				}
			
			Product new_product = new Product(productID, productName, quantity, price);
			shopping_list.add(new_product);
				
			} 
			scanner.close();
			
			}catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
			}
			
			return shopping_list;
			}
		/*
		 * @param filepath - File path to write Shoppping_Cart Object data to csv file 
		 * @param shopping_list - Shopping_Cart Object ArrayList to write to file
		 * 
		 */
		public static void exportFile(String filepath, ArrayList<Product>shopping_list) {
			
			File file = new File(filepath);
			try {
				FileWriter writer = new FileWriter(file);
				
				for(int i=0; i<shopping_list.size(); i++) {
					Product temp_product = shopping_list.get(i);
					writer.write(temp_product.productID + "," + temp_product.productName + "," + temp_product.quantity + "," + temp_product.productPrice + "\n");
					writer.flush();
				}
				writer.close();
			}catch (IOException e) {
				System.out.println("Could not write to file");
			}
			
		}
			
	}


