import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Summary extends Cart{
	
	public Summary(ArrayList<Product> productList, File file) {
		super(productList, file);
		// TODO Auto-generated constructor stub
	} 
	
	public boolean pay(double cash) {
		boolean paid = false;
		double cost = 0;
		for(int i=0; i<productList.size(); i++) {
			cost = cost + productList.get(i).productPrice;
		}
		if(cash-cost>0) {
			paid = true;
		}
		return paid; 
	}
	
	public void printReceipt(File file, String fileLocation) throws IOException {
		file = new File(fileLocation);
		file.createNewFile();
		PrintWriter writer = new PrintWriter(file);
		writer.print("");
		for(int i=0; i<productList.size(); i++) {
			Product product = productList.get(i);
			String data = product.productID+","+product.productName+","+
			Double.toString(product.productPrice)+","+Integer.toString(product.quantity)+","+Double.toString(product.productPrice*(product.quantity));
			writer.print(data);
		}
		writer.close(); 
		
	}
	
	public static void main(String[] args) throws IOException {
		
		ArrayList<Product> list = new ArrayList<Product>();
		File file = new File("C:\\Users\\Yvonne\\Desktop\\shoppinglist.csv");
		
		Summary sum = new Summary(list, file);
		sum.importFile("C:\\Users\\Yvonne\\Desktop\\shoppinglist.csv");
		sum.printReceipt(file, "C:\\Users\\Yvonne\\Desktop\\receipt.csv");
		
	}
	
}
	
	


