import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

 public class Cart {
	 
	 public ArrayList<Product> productList;
	 public File file;
	 
	 public Cart(ArrayList<Product> productList, File file) {
		 this.file = file;
		 this.productList = productList;
		 
	 }
	
	 
	 public void addItem(Product input) {
		 
		 this.productList.add(input);
		 
	 }
	 
	 public void remove(String productName) {
		 
		 for(int i=0; i<this.productList.size(); i++) {
			 
			 if(this.productList.get(i).productName == productName) {
				 this.productList.remove(i);
			 }
			 
		 }
		 
	 }
	 
	 public void importFile(String location) throws FileNotFoundException {
		 
		 this.file = new File(location); 
		 Scanner sc = new Scanner(file);
		 sc.useDelimiter(",|\n");
		 while(sc.hasNext()) {
			 Product input = new Product(sc.next(), sc.next(), Integer.parseInt(sc.next()), Double.parseDouble(sc.next()));
			 addItem(input);
		 }
		 sc.close();
	 }
	 
	 public void printProductList() {
		 
		 for(int i=0; i<this.productList.size(); i++) {
			 System.out.println(this.productList.get(i).productName);
		 }
		 
	 }
	 
	
 } 
 
	 

